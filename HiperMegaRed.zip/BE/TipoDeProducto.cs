﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HiperMegaRed.BE
{
    public enum TipoDeProducto
    {
        Mouse,
        Teclado,
        PAD,
        Auriculares,
        Microfono,
        Headset,
        Silla,
        Motherboard,
        CPU,
        GPU,
        RAM,
        Otros
    }
}
