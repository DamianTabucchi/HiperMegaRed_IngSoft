﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HiperMegaRed.BE
{
    public class Factura : AbstractGuidEntity
    {
        public Factura()
        {

        }
        public Factura(OrdenDePago ord)
        {
            Id = Guid.NewGuid();
            factura_orden_id = ord.Id;
            factura_cliente_dni = ord.orden_cliente_dni;
            factura_fecha = DateTime.Now;
            factura_monto = ord.orden_total;
        }

        public Guid factura_orden_id { get; set; }
        public DateTime factura_fecha { get; set; }
        public decimal factura_cliente_dni { get; set; }
        public double factura_monto { get; set; }

        public bool factura_productos_entregados { get; set; } = false;
    }
}
