﻿using HiperMegaRed.BE;
using HiperMegaRed.DAL;
using HiperMegaRed.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HiperMegaRed.BLL
{
    public class ClienteBLL
    {
        private static ClienteBLL instance = new ClienteBLL();
        private static ClienteDAL clienteDAL = ClienteDAL.GetInstance();
        private CryptoManager cryptoManager = new CryptoManager("War");
        private ClienteBLL() { }
        // Instance => instance; es lo mismo que escribir public static UserBLL Instance { get { return instance; } }
        public static ClienteBLL Instance => instance;

        public IList<Cliente> GetAll()
        {
            //var cliEnc = clienteDAL.GetAll();
            //IList<Cliente> cliDes = new List<Cliente>();
            //foreach (Cliente c in cliEnc)
            //{
            //    cliDes.Add(DesencriptarDatosCliente(c));
            //}
            //return cliDes;
            return clienteDAL.GetAll();
        }

        public Cliente FindByDNI(decimal doc)
        {
            //var cl = clienteDAL.FindByDNI(doc);
            //if (cl != null)
            //{
            //    return DesencriptarDatosCliente(cl);
            //}
            //else
            //{
            //    return cl;
            //}
            return clienteDAL.FindByDNI(doc);
        }


        //Validaciones aca
        public void SaveClient(Cliente c)
        {
            //var cEn = EncriptarDatosCliente(c);
            //clienteDAL.SaveClient(cEn);
            clienteDAL.SaveClient(c);
        }

        //public Cliente EncriptarDatosCliente(Cliente c)
        //{
        //    Cliente cEncriptado = c;
        //    cEncriptado.cliente_mail = cryptoManager.EncriptAES(c.cliente_mail);
        //    cEncriptado.cliente_telefono = cryptoManager.EncriptAES(c.cliente_telefono);
        //    return cEncriptado;
        //}

        //public Cliente DesencriptarDatosCliente(Cliente c)
        //{
        //    Cliente cDesencriptado = c;
        //    cDesencriptado.cliente_mail = cryptoManager.DecryptAES(c.cliente_mail);
        //    cDesencriptado.cliente_telefono = cryptoManager.DecryptAES(c.cliente_telefono);
        //    return cDesencriptado;
        //}
    }
}
