﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HiperMegaRed.Services
{
    public class SessionManager
    {
        private static SessionManager _session = new SessionManager();

        private IUser _user;

        private SessionManager() { }

        public static SessionManager GetInstance { get { return _session; } }

        public IUser User
        {
            get
            {
                return _user;
            }
        }


        public void Login (IUser usuario)
        {
            _user = usuario;
        }

        public void Logout()
        {
            _user = null;
            
        }

        public bool IsLogged()
        {
            return _user != null;
        }
        public bool IsNotLogged()
        {
            return !IsLogged();
        }
    }
}
