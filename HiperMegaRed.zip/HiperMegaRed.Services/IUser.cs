﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HiperMegaRed.Services
{
    public interface IUser
    {
        Guid Id { get; }
        string Username { get; }

    }
}
