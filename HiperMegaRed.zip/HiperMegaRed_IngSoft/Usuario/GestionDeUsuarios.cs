﻿using HiperMegaRed.BE;
using HiperMegaRed.BLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HiperMegaRed_IngSoft.Usuario
{

    public partial class FrmGestionUsuarios : Form
    {
        public UserBLL userbll = UserBLL.Instance;
        //private User editable;
        public FrmGestionUsuarios()
        {
            InitializeComponent();
            ActualizarGrilla();
            ClearData();
        }

        public void ActualizarGrilla()
        {
            dgvUsuarios.DataSource = userbll.GetAll();
            dgvUsuarios.Columns["Password"].Visible = false;
            dgvUsuarios.Columns["Id"].Visible = false;


        }
        public void ClearData()
        {
            txtDNI.Text = "";
            txtNombre.Text = "";
            txtLogin.Text = "";
            txtApellido.Text = "";
            txtTel.Text = "";
            txtEmail.Text = "";

            btnMod.Enabled = false;
            btnAplicar.Enabled = false;
            btnEliminar.Enabled = false;
            btnAdd.Enabled = true;
            btnCancel.Enabled = false;
        }
        private void txtApellido_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void btnMod_Click(object sender, EventArgs e)
        {
            DataGridViewRow fila = dgvUsuarios.CurrentRow;
            txtDNI.Text = Convert.ToString(fila.Cells["DNI"].Value);
            txtNombre.Text = Convert.ToString(fila.Cells["Name"].Value);
            txtApellido.Text = Convert.ToString(fila.Cells["Lastname"].Value);
            txtLogin.Text = Convert.ToString(fila.Cells["Username"].Value);
            txtTel.Text = Convert.ToString(fila.Cells["Phone"].Value);
            txtEmail.Text = Convert.ToString(fila.Cells["Mail"].Value);
            var failcount = Convert.ToString(fila.Cells["FailCount"].Value);
            if (int.Parse(failcount) > 2)
            {
                chbBlock.Checked = true;
            }
            else
            {
                chbBlock.Checked = false;
            }
            btnAplicar.Enabled = true;
        }

        private void dgvUsuarios_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvUsuarios.SelectedRows != null)
            {
                btnMod.Enabled = true;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

        }
    }
}
