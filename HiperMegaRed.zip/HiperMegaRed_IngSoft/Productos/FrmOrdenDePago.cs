﻿using HiperMegaRed.BE;
using HiperMegaRed.BLL;
using HiperMegaRed.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HiperMegaRed_IngSoft.Productos
{
    public partial class FrmOrdenDePago : Form
    {
        private ClienteBLL clienteBLL = ClienteBLL.Instance;
        private OrdenDePagoBLL ordenBLL = OrdenDePagoBLL.Instance;
        private ProductoBLL productoBLL = ProductoBLL.Instance;
        private static OrdenDePago orden = new OrdenDePago();
        private HiperMegaRed.BE.Cliente client = new HiperMegaRed.BE.Cliente();
        private IList<Producto> productos = new List<Producto>();
        private FacturaBLL facturaBLL = FacturaBLL.Instance;
        private Factura fact;

        public FrmOrdenDePago()
        {
            InitializeComponent();
        }

        private void FrmOrdenDePago_Load(object sender, EventArgs e)
        {
            ObtenerOrdenes();
            
        }

        public void ObtenerOrdenes()
        {
            cbOrdenes.DataSource = ordenBLL.GetUnpaid();
            cbOrdenes.DisplayMember = "orden_fecha";
        }

        public void RefreshData()
        {
            dgvProductos.DataSource = null;
            txtDNI.Text = "";
            txtNombre.Text = "";
            txtApellido.Text = "";
            productos = new List<Producto>();
            client = null;
            orden = null;
            txtFecha.Text = "";
            txtTotal.Text = "";
            btnPagar.Enabled = false;
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {

            orden = (OrdenDePago)cbOrdenes.SelectedItem;
            txtFecha.Text = orden.orden_fecha.ToString();
            if (clienteBLL.FindByDNI(orden.orden_cliente_dni) is null)
            {
                MessageBox.Show("El DNI ingresado no existe en la base de datos, registre al cliente");
                var FrmRegClient = new Cliente.FrmRegistrarCliente(orden.orden_cliente_dni);
                FrmRegClient.MdiParent = this.MdiParent;
                FrmRegClient.Show();

            }
            else
            {
                client = clienteBLL.FindByDNI(orden.orden_cliente_dni);
                txtDNI.Text = client.cliente_dni.ToString();
                txtNombre.Text = client.cliente_nombre;
                txtApellido.Text = client.cliente_apellido;
                productos = productoBLL.FindByCart(orden.orden_carrito_id);
                dgvProductos.DataSource = productos;
                dgvProductos.Columns["producto_marca"].Visible = false;
                dgvProductos.Columns["producto_modelo"].Visible = false;
                dgvProductos.Columns["producto_descripcion"].Visible = false;
                dgvProductos.Columns["producto_stock"].Visible = false;
                dgvProductos.Columns["id"].Visible = false;
                dgvProductos.Columns["producto_deposito"].Visible = false;
                txtTotal.Text = orden.orden_total.ToString();
                btnPagar.Enabled = true;
            }

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void btnPagar_Click(object sender, EventArgs e)
        {
            orden.orden_pago = true;
            try
            {
                var hecho = ordenBLL.UpdateOrden(orden);
                if (hecho == 1)
                {
                    MessageBox.Show("Se ha actualizado la orden");
                    fact = new Factura(orden);
                    facturaBLL.SaveFact(fact);
                    MessageBox.Show("Se ha creado la factura");
                    RefreshData();
                    ObtenerOrdenes();
                }
                else
                {
                    throw new ValidationException("Error");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ha ocurrido un error:" + ex.Message);
            }
        }

        private void cbOrdenes_SelectedIndexChanged(object sender, EventArgs e)
        {
            RefreshData();
        }
    }
}
